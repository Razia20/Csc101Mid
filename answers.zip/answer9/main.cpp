#include <iostream>

using namespace std;

int main()
{
    int hour;
    int minute;
    cout << "Input hours: " ;
    cin >> hour;
    cout << "Input minutes: ";
    cin >> minute;
    int total = (hour*60) + minute;
    cout << "Total minutes: " << total <<endl;
    return 0;
}
