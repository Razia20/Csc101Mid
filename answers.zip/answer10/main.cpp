#include <iostream>

using namespace std;

int main()
{
    string forename, surname;
    int dob;
    cout << "Please enter your forename: ";
    cin >> forename;
    cout << "Please enter your surname: ";
    cin >> surname;
    cout << "Please enter your year of birth: ";
    cin >> dob;

    cout <<"\n"<< forename << " " << surname << " " <<dob <<endl;
    return 0;
}
