#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{
    char c[256];
    cout << "Please enter your string: " ;
    cin >> c;
    double d = strtod(c, NULL);
    cout << "Converting to Double: " << d <<endl;
    return 0;
}
