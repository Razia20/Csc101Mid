#include <iostream>

using namespace std;

int main()
{
    int age;
    cout << "Please enter your age: ";
    cin >> age;

    if(age >= 18){
        cout << "Congratulations! You are eligible for casting your vote"<<endl;
    }
    else {
        cout << "Sorry. You are not eligible for voting"<<endl;
    }
    return 0;
}
