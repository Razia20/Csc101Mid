#include <iostream>

using namespace std;

void printF(char c){
    cout<< c << c << c <<c <<c <<c <<endl;
    cout<< c << endl;
    cout << c <<endl;
    cout<< c << c << c <<c <<c <<endl;
    cout<< c << endl;
    cout << c <<endl;
    cout<< c << endl;
}

int main()
{
    char input;
    cout << "Please enter the character of which you want to print the F shape:" ;
    cin >> input;
    printF(input);
    return 0;
}
