#include <iostream>

using namespace std;

int main()
{
    int numerator, denominator, quotient, remainder;

    cout << "Please enter your factor's numerator: ";
    cin >> numerator ;

    cout << "Please enter your factor's denominator: ";
    cin >> denominator;

    quotient = numerator / denominator;

    remainder = numerator % denominator;

    cout << "Quotient: " << quotient << endl;
    cout << "Remainder: " <<remainder << endl;
    return 0;
}
