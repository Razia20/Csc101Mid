#include <iostream>

using namespace std;

int main()
{
    double PI = 3.1416;
    double sp;
    double radius;
    cout << "Input the radius of the sphere : ";
    cin >> radius;

    double rad = radius * radius * radius;
    sp = ((4* PI * rad)/3);  //sphere volume = 4/4* PI* radious^3
    cout << "The volume of sphere is: " <<sp << endl;
    return 0;
}
