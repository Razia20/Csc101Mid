#include <iostream>

using namespace std;

int main()
{
    int num1, num2;
    cout << "Please enter your first number: ";
    cin >> num1;
    cout << "Please enter your second number: ";
    cin >> num2;

    if(num1 == num2){
        cout << num1 << " and "  << num2 << " are equal" <<endl;
    }
    else {
        cout << num1 << " and "  << num2 << " are not equal" <<endl;
    }
    return 0;
}
