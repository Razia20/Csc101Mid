#include <iostream>

using namespace std;

void unsedCheck(char c[]){

}

int main()
{
    char inputString[20];
    int s = 1, n = 0, i = 0;
    cout << "Please enter your string: " ;
    cin >> inputString;
    if(inputString[0] == '-'){
        s = 1; //making it unsigned
        i = 1;
    }

    while(inputString[i] != '\0'){
        if(inputString[i] >= '0' && inputString[i] <= '9'){
            n = n*10 + inputString[i] - '0';
        } else {
            break;
        }
        i++;
    }

    n = n * s;
    cout << "Unsigned Integer:: " << n << endl;
    return 0;
}
